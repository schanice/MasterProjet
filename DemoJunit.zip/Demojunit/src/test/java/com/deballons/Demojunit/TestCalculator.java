package com.deballons.Demojunit;

import junit.framework.TestCase;

public class TestCalculator extends TestCase {

}
